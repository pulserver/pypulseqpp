"""
=======================================
2D Cartesian multi-echo gradient echo
=======================================

A spoiled low-flip-angle excitation is followed by several Cartesian gradient
echoes of the same phase-encode line. Gradient and RF spoiling suppress
residual transverse coherence before the next TR. The echo train samples T2*
decay while TR and flip angle determine the T1 weighting. Multi-echo GRE is
used for T2*/R2* mapping, susceptibility mapping, and structural imaging.
"""

# sphinx_gallery_start_ignore
import matplotlib

matplotlib.use("Agg")

# sphinx_gallery_end_ignore

# %%
# Four-echo train
# ---------------
#
# Four echoes after each excitation, with readout gradients of alternating
# polarity.

import pypulseqpp as pp
from pypulseqpp.sequences import gre_multiecho2D_sequence

baseline = gre_multiecho2D_sequence(
    n_x=192, n_y=192, n_slices=1, n_echoes=4, te=None, tr=None, n_dummy=0
)
print(f"{baseline.num_blocks} blocks, {baseline.duration()[0]:.2f} s")
print("TE", [round(t * 1e3, 2) for t in baseline.get_definition("TE")], "ms")

# %%
# Sequence diagram
# ----------------

baseline.paper_plot()

# %%
# Sampling order
# --------------
#
# Colour encodes acquisition order. The echoes of one excitation sample the
# same phase-encode line.

pp.plot.plot_kspace(baseline, color_by="order", plane="xy", show_trajectory=False)

# %%
# A longer echo train
# -------------------
#
# Additional echoes extend the sampled decay curve and increase the minimum
# repetition time and final echo time.

alternative = gre_multiecho2D_sequence(
    n_x=192, n_y=192, n_slices=1, n_echoes=8, te=None, tr=None, n_dummy=0
)

# sphinx_gallery_start_ignore
print(f"{'':16} {'blocks':>8} {'duration (s)':>13} {'acquisitions':>13}")
for name, seq in (("4 echoes", baseline), ("8 echoes", alternative)):
    print(
        f"{name:16} {seq.num_blocks:8d} {seq.duration()[0]:13.2f} "
        f"{seq._native.num_adc():13d}"
    )
# sphinx_gallery_end_ignore

# %%
pp.plot.plot_kspace(alternative, color_by="order", plane="xy", show_trajectory=False)

# %%
