r"""
===================
Echo planar imaging
===================

The gradient echo of :doc:`/generated/gallery/01-pulseq-basics/03_gradient_echo`
acquires one k-space line per excitation, and the previous lesson,
:doc:`/generated/gallery/02-spoiling/01_spoiling`, kept the residual
magnetisation of one repetition out of the next. This lesson acquires the
whole matrix after a single excitation. It first follows the readout gradient
with further readout gradients of alternating polarity, each forming an echo,
and then adds a phase-encode blip between the echoes so that each echo
acquires a different line. It measures the two effects that limit such an
acquisition: the signal decay over an echo train tens of milliseconds long,
and the sensitivity of a train of alternating readouts to a delay between the
gradient waveform and the acquisition. The next lesson,
:doc:`/generated/gallery/04-non-cartesian/01_radial`, covers k-space with
rotated readouts instead.

Learning objectives
-------------------

After this lesson, you should be able to:

- build a train of readout gradients of alternating polarity, each with its
  own ADC event, and locate its echoes from the k-space analysis;
- explain why the even echoes are acquired in reverse order;
- build a single-shot echo planar readout with a one-line phase-encode blip;
- read the traversal order of the echo train from the k-space trajectory;
- compute the point-spread function that :math:`T_2^*` decay across the
  train produces along the phase-encode direction;
- measure the alternating k-space displacement a gradient delay introduces,
  and relate it to the half-field-of-view ghost.
"""

# sphinx_gallery_start_ignore
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

PAGE_WIDTH = 7.8  # inches, the width of the documentation column
# sphinx_gallery_end_ignore

# %%
# A train of readouts
# -------------------
#
# A readout gradient traverses one k-space line from one end to the other. A
# second gradient of the opposite polarity traverses it back, so a train of
# them needs no rewinder between the echoes and forms one echo per gradient.
# The gradients are played back to back, so the echo spacing is the duration of
# one readout gradient, ramps included. Every second echo is acquired in the
# opposite direction, and its samples are in the reverse order of the odd
# echoes'.

import numpy as np

import pypulseqpp as pp

system = pp.Opts(
    max_grad=32.0,
    grad_unit="mT/m",
    max_slew=130.0,
    slew_unit="T/m/s",
    rf_dead_time=100e-6,
    rf_ringdown_time=20e-6,
    adc_dead_time=10e-6,
)

FOV = 220e-3
MATRIX = 64
THICKNESS = 5e-3
FLIP_ANGLE_DEG = 90.0
DWELL = 4e-6

rf, gz, gz_reph = pp.make_sinc_pulse(
    flip_angle=np.deg2rad(FLIP_ANGLE_DEG),
    duration=2e-3,
    slice_thickness=THICKNESS,
    apodization=0.5,
    time_bw_product=4.0,
    delay=system.rf_dead_time,
    system=system,
    use="excitation",
    return_gz=True,
)

acquisition = MATRIX * DWELL
raster = system.grad_raster_time
gx = pp.make_trapezoid(
    channel="x",
    amplitude=MATRIX / FOV / acquisition,
    flat_time=raster * np.ceil(acquisition / raster),
    system=system,
)
adc = pp.make_adc(num_samples=MATRIX, dwell=DWELL, delay=gx.rise_time, system=system)
gx_pre = pp.make_trapezoid(
    channel="x",
    area=-(gx.amplitude * gx.rise_time / 2 + (MATRIX / 2 + 0.5) / FOV),
    duration=5e-4,
    system=system,
)

ECHOES = 6

train = pp.Sequence(system=system)
train.add_block(rf, gz)
train.add_block(gx_pre, gz_reph)
for echo in range(ECHOES):
    train.add_block(pp.scale_grad(gx, (-1.0) ** echo), adc)

# %%
# The analysis gives the k-space location of every sample of every acquisition
# window. Along the readout axis the train is a triangle wave between the two
# ends of the line, and an echo is where it crosses zero.

k_train, _, t_train_excitation, _, t_train = train.calculate_kspace()
kx_train = k_train[0] * FOV / MATRIX * 2
echo_times = np.array(
    [
        t_train[
            echo * MATRIX + int(np.argmin(np.abs(kx_train[echo * MATRIX :][:MATRIX])))
        ]
        - t_train_excitation[0]
        for echo in range(ECHOES)
    ]
)
print(
    "echo times (ms): "
    + ", ".join(f"{1e3 * time:.2f}" for time in echo_times)
    + f"\nspacing {1e3 * np.diff(echo_times).mean():.3f} ms, "
    f"readout gradient {1e3 * pp.calc_duration(gx):.3f} ms"
)

# sphinx_gallery_start_ignore
figure, axis = plt.subplots(figsize=(PAGE_WIDTH, 3.0), layout="constrained")
for echo in range(ECHOES):
    window = slice(echo * MATRIX, (echo + 1) * MATRIX)
    axis.plot(
        1e3 * (t_train[window] - t_train_excitation[0]),
        kx_train[window],
        lw=1.4,
        color="C0" if echo % 2 == 0 else "C7",
    )
axis.plot([], [], color="C0", label="odd echoes")
axis.plot([], [], color="C7", label="even echoes")
axis.plot(1e3 * echo_times, np.zeros(ECHOES), "o", color="C2", ms=4, label="echo")
axis.set_xlabel("time from the excitation (ms)")
axis.set_ylabel(r"$k_x$ / $k_\mathrm{max}$")
figure.legend(ncols=3, loc="outside upper left")
# sphinx_gallery_end_ignore

# %%
# The samples the analysis reports are not one line acquired six times: the
# even echoes run from :math:`+k_\mathrm{max}` to :math:`-k_\mathrm{max}`, so
# a reconstruction has to reverse them before they are lines of the same
# matrix. The last section of this lesson measures what a delay between the
# gradient and the acquisition does to such a train.

# %%
# One excitation, every line
# --------------------------
#
# A phase-encode blip between the echoes advances the acquisition by one line,
# and the train runs the length of the matrix. The prewinder on the
# phase-encode axis starts the train at one edge of k-space.

gy_pre = pp.make_trapezoid(
    channel="y", area=-MATRIX / (2 * FOV), duration=5e-4, system=system
)
blip = pp.make_phase_blip(channel="y", fov=FOV, steps=1, system=system)

seq = pp.Sequence(system=system)
seq.add_block(rf, gz)
seq.add_block(gx_pre, gy_pre, gz_reph)
for echo in range(MATRIX):
    readout = pp.scale_grad(gx, (-1.0) ** echo)
    if echo == 0:
        seq.add_block(readout, adc)
    else:
        seq.add_block(readout, blip, adc)

ok, errors = seq.check_timing()
echo_spacing = pp.calc_duration(gx)
print(
    f"timing {ok}, {seq.num_blocks} blocks, "
    f"echo spacing {1e3 * echo_spacing:.3f} ms, "
    f"train {1e3 * MATRIX * echo_spacing:.1f} ms, "
    f"blip {1e6 * pp.calc_duration(blip):.0f} us"
)

seq.paper_plot()

# %%
# The trajectory
# --------------
#
# One shot, coloured by the rank of each echo in the train: the acquisition
# starts at one corner of k-space and works across it, reversing direction at
# every line.

pp.plot.plot_kspace(seq, color_by="echo", plane="xy")

# %%
# Decay across the train
# ----------------------
#
# The last line is acquired tens of milliseconds after the first, and the
# transverse signal has decayed over that interval. Along the phase-encode
# direction the acquired data are therefore the true k-space multiplied by a
# decaying envelope, and the image is convolved with that envelope's transform.
#
# The echo times come from the analysis, and the line each echo lands on from
# the k-space it reports, so the envelope follows the sequence's own ordering.

k_adc, _, t_excitation, _, t_adc = seq.calculate_kspace()
echo_time = t_adc.reshape(MATRIX, MATRIX).mean(axis=1) - t_excitation[0]
line = np.round(k_adc[1].reshape(MATRIX, MATRIX)[:, 0] * FOV).astype(int)
order = np.argsort(line)

T2_STARS = (20e-3, 40e-3, 60e-3, 100e-3)


def point_spread(t2_star):
    """The phase-encode point-spread function the decay produces."""
    envelope = np.exp(-echo_time[order] / t2_star)
    spread = np.abs(np.fft.fftshift(np.fft.fft(np.fft.ifftshift(envelope))))
    return spread / spread.max()


def width(spread):
    """Full width at half maximum, in pixels, by linear interpolation."""
    above = np.flatnonzero(spread >= 0.5)
    first, last = above[0], above[-1]
    left = np.interp(0.5, spread[first - 1 : first + 1], [first - 1, first])
    right = np.interp(0.5, spread[last : last + 2][::-1], [last + 1, last])
    return right - left


widths = {t2_star: width(point_spread(t2_star)) for t2_star in T2_STARS}

# sphinx_gallery_start_ignore
print(f"\n{'T2*':>8}  {'decay over the train':>22}  {'point spread':>14}")
for t2_star in T2_STARS:
    print(
        f"{1e3 * t2_star:5.0f} ms  "
        f"{np.exp(-echo_time[order][-1] / t2_star):22.3f}  "
        f"{widths[t2_star]:11.2f} px"
    )

figure, (envelope_axis, spread_axis) = plt.subplots(
    1, 2, figsize=(PAGE_WIDTH, 3.2), layout="constrained"
)
pixels = np.arange(MATRIX) - MATRIX // 2
for t2_star in T2_STARS:
    label = f"{1e3 * t2_star:.0f} ms"
    envelope_axis.plot(
        line[order], np.exp(-echo_time[order] / t2_star), lw=1.2, label=label
    )
    spread_axis.plot(pixels, point_spread(t2_star), lw=1.2, label=label)
envelope_axis.set_xlabel("phase-encode line")
envelope_axis.set_ylabel("signal")
spread_axis.set_xlim(-8, 8)
spread_axis.set_xlabel("pixels along the phase-encode direction")
spread_axis.set_ylabel("point spread, normalised")
figure.legend(
    *envelope_axis.get_legend_handles_labels(),
    title=r"$T_2^*$",
    ncols=4,
    loc="outside upper left",
)
# sphinx_gallery_end_ignore

# %%
# The envelope is not centred on the middle of k-space: the train runs from one
# edge to the other, so the decay is monotonic across the lines rather than
# symmetric about the line the echo is on. The result is a point-spread
# function that is both wider than one pixel and asymmetric: the blurring along
# the phase-encode direction of an echo planar image. At
# the shortest :math:`T_2^*` here the signal at the last line is a tenth of
# the first and the point spread is half again as wide as a pixel; at the
# longest it is within a tenth of a pixel of the unblurred width.
#
# The remedies are a shorter echo spacing, fewer lines per shot (a segmented
# acquisition), and acquiring fewer lines outright, by partial Fourier or by
# parallel imaging.

# %%
# Gradient delay and the odd echoes
# ---------------------------------
#
# A delay between the gradient waveform and the acquisition displaces every
# sample along the readout direction by the distance k-space travels in that
# delay. The readouts alternate in polarity, so the displacement alternates in
# sign: the odd and the even lines of the matrix are shifted in opposite
# directions.
#
# :meth:`~pypulseqpp.Sequence.calculate_kspace` takes the delay as a
# parameter, so the displacement is measured from the trajectory the analysis
# reports rather than computed beside it.

DELAYS = np.array([0.0, 1e-6, 2e-6, 4e-6, 8e-6])

displacement = []
for delay in DELAYS:
    delayed = seq.calculate_kspace(trajectory_delay=delay)[0]
    kx = delayed[0].reshape(MATRIX, MATRIX)
    # The echo of each line, where the ideal trajectory crosses zero.
    centre = kx[:, MATRIX // 2] * FOV
    displacement.append(
        {
            "delay": delay,
            "samples": float(np.abs(centre[::2].mean() - centre[1::2].mean()) / 2),
        }
    )

# sphinx_gallery_start_ignore
print(f"\n{'delay':>10}  {'odd-even displacement':>24}")
for row in displacement:
    print(f"{1e6 * row['delay']:7.1f} us  {row['samples']:20.3f} samples")

figure, axis = plt.subplots(figsize=(PAGE_WIDTH * 0.58, 3.0), layout="constrained")
axis.plot(
    1e6 * DELAYS,
    [row["samples"] for row in displacement],
    "o-",
    lw=1.2,
    ms=5,
    label="displacement of a line from the ideal",
)
axis.set_xlabel("gradient delay (us)")
axis.set_ylabel("samples")
figure.legend(loc="outside upper left")
# sphinx_gallery_end_ignore

# %%
# The displacement is the delay divided by the dwell time, and it is the same
# for every line, so the odd and the even lines differ only in its sign. A quantity that alternates from one line to the next along the
# phase-encode direction is, after the transform, an image displaced by half
# the field of view, which is the ghost an uncorrected echo planar acquisition
# shows. Measuring the delay and correcting for it are reconstruction steps,
# outside the scope of this package.
