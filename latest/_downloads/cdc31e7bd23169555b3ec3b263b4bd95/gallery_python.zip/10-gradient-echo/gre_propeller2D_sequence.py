"""
============================
2D PROPELLER gradient echo
============================

A spoiled low-flip-angle excitation is followed by one Cartesian line from a
rotating PROPELLER blade. Gradient and RF spoiling suppress residual transverse
coherence between repetitions. TR, flip angle, and TE determine contrast. The
overlapping central k-space region supports motion estimation in structural
imaging.
"""

# sphinx_gallery_start_ignore
import matplotlib

matplotlib.use("Agg")

# sphinx_gallery_end_ignore

# %%
# Sixteen-line blades
# -------------------
#
# Sixteen lines per blade, with the number of blade orientations chosen to
# cover the k-space disc.

import pypulseqpp as pp
from pypulseqpp.sequences import gre_propeller2D_sequence

baseline = gre_propeller2D_sequence(
    n=192, blade_width=16, n_slices=1, te=None, tr=None, n_dummy=0
)
print(f"{baseline.num_blocks} blocks, {baseline.duration()[0]:.2f} s")


# %%
# Sequence diagram
# ----------------

baseline.paper_plot()

# %%
# Sampling order
# --------------
#
# The colour encodes blade acquisition order. Each blade is a band
# of parallel lines; the bands overlap at the centre.

pp.plot.plot_kspace(baseline, color_by="shot", plane="xy")

# %%
# Wider blades
# ------------
#
# Increasing the blade width reduces the number of blade orientations and
# increases the duration of each blade. The larger shared central-k-space
# region provides additional data for motion estimation.

alternative = gre_propeller2D_sequence(
    n=192, blade_width=32, n_slices=1, te=None, tr=None, n_dummy=0
)

# sphinx_gallery_start_ignore
print(f"{'':16} {'blocks':>8} {'duration (s)':>13} {'acquisitions':>13}")
for name, seq in (("16 lines", baseline), ("32 lines", alternative)):
    print(
        f"{name:16} {seq.num_blocks:8d} {seq.duration()[0]:13.2f} "
        f"{seq._native.num_adc():13d}"
    )
# sphinx_gallery_end_ignore

# %%
pp.plot.plot_kspace(alternative, color_by="shot", plane="xy")

# %%
